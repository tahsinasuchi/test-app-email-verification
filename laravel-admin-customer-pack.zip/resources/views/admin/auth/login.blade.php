<x-layout :title="'Admin Login'">
    <h1>Admin Login</h1>
    <form method="post" action="{{ route('admin.login.post') }}">
        @csrf
        <div><label>Login ID <input name="login_id" value="{{ old('login_id') }}" required></label></div>
        <div><label>Password <input name="password" type="password" required></label></div>
        <div><label><input type="checkbox" name="remember" value="1"> Remember me</label></div>
        <button type="submit">Login</button>
    </form>
    <p><a href="{{ route('admin.register') }}">Create account</a></p>
</x-layout>
