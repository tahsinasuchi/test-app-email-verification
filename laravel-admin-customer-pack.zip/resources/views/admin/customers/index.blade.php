<x-layout :title="'Members'">
    <h1>Members</h1>
    <form>
        <input name="s" value="{{ request('s') }}" placeholder="Search name/email/login_id">
        <button>Search</button>
    </form>
    <p>
        <a href="{{ route('admin.customers.create') }}">+ New</a> |
        <a href="{{ route('admin.customers.csv') }}">Export CSV</a>
    </p>
    <table border="1" cellpadding="4">
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Login ID</th><th>Verified</th><th>Actions</th></tr>
        @foreach($customers as $c)
            <tr>
                <td>{{ $c->id }}</td>
                <td>{{ $c->name }}</td>
                <td>{{ $c->email }}</td>
                <td>{{ $c->login_id }}</td>
                <td>{{ $c->email_verified_at ? 'Verified' : 'Pending' }}</td>
                <td><a href="{{ route('admin.customers.edit', $c->id) }}">Edit</a></td>
            </tr>
        @endforeach
    </table>
    {{ $customers->links() }}
</x-layout>
