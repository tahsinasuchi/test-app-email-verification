<x-layout :title="'Member Form'">
    <h1>Member {{ $customer->id ? 'Edit' : 'New' }}</h1>
    <form method="post" action="{{ $customer->id ? route('admin.customers.update',$customer->id) : route('admin.customers.store') }}">
        @csrf
        <div><label>Name <input name="name" value="{{ old('name', $customer->name) }}" required></label></div>
        <div><label>Email <input name="email" type="email" value="{{ old('email', $customer->email) }}" required></label></div>
        <div><label>Login ID <input name="login_id" value="{{ old('login_id', $customer->login_id) }}" required></label></div>
        <div><label>Password <input name="password" type="password" {{ $customer->id ? '' : 'required' }}></label></div>
        <div><label>Confirm Password <input name="password_confirmation" type="password" {{ $customer->id ? '' : 'required' }}></label></div>
        <button type="submit">{{ $customer->id ? 'Update' : 'Create' }}</button>
    </form>
    <p><a href="{{ route('admin.customers.index') }}">Back to list</a></p>
</x-layout>
