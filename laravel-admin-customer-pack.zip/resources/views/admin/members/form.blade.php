<x-layout :title="'Admin Form'">
    <h1>Admin {{ $admin->id ? 'Edit' : 'New' }}</h1>
    <form method="post" action="{{ $admin->id ? route('admin.members.update',$admin->id) : route('admin.members.store') }}">
        @csrf
        <div><label>Name <input name="name" value="{{ old('name', $admin->name) }}" required></label></div>
        <div><label>Email <input name="email" type="email" value="{{ old('email', $admin->email) }}" required></label></div>
        <div><label>Login ID <input name="login_id" value="{{ old('login_id', $admin->login_id) }}" required></label></div>
        <div><label>Password <input name="password" type="password" {{ $admin->id ? '' : 'required' }}></label></div>
        <div><label>Confirm Password <input name="password_confirmation" type="password" {{ $admin->id ? '' : 'required' }}></label></div>
        <button type="submit">{{ $admin->id ? 'Update' : 'Create' }}</button>
    </form>
    <p><a href="{{ route('admin.members.index') }}">Back to list</a></p>
</x-layout>
