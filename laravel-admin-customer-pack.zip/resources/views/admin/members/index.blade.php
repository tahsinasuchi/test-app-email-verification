<x-layout :title="'Admin Members'">
    <h1>Admin Members</h1>
    <form>
        <input name="s" value="{{ request('s') }}" placeholder="Search name/email/login_id">
        <button>Search</button>
    </form>
    <p>
        <a href="{{ route('admin.members.create') }}">+ New</a> |
        <a href="{{ route('admin.members.csv') }}">Export CSV</a>
    </p>
    <table border="1" cellpadding="4">
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Login ID</th><th>Verified</th><th>Actions</th></tr>
        @foreach($admins as $a)
            <tr>
                <td>{{ $a->id }}</td>
                <td>{{ $a->name }}</td>
                <td>{{ $a->email }}</td>
                <td>{{ $a->login_id }}</td>
                <td>{{ $a->email_verified_at ? 'Verified' : 'Pending' }}</td>
                <td><a href="{{ route('admin.members.edit', $a->id) }}">Edit</a></td>
            </tr>
        @endforeach
    </table>
    {{ $admins->links() }}
</x-layout>
