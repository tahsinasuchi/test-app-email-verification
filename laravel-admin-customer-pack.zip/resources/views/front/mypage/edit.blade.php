<x-layout :title="'My Page'">
    <h1>My Page - Edit</h1>
    <form method="post" action="{{ route('front.mypage.update') }}">
        @csrf
        <div><label>Name <input name="name" value="{{ old('name', $customer->name) }}" required></label></div>
        <div><label>Email <input name="email" type="email" value="{{ old('email', $customer->email) }}" required></label></div>
        <div><label>Login ID <input name="login_id" value="{{ old('login_id', $customer->login_id) }}" required></label></div>
        <div><label>New Password <input name="password" type="password"></label></div>
        <div><label>Confirm Password <input name="password_confirmation" type="password"></label></div>
        <button type="submit">Save</button>
    </form>
    <form method="post" action="{{ route('front.logout') }}">
        @csrf
        <button type="submit">Logout</button>
    </form>
</x-layout>
