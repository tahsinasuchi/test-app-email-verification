<x-layout :title="'Member Entry'">
    <h1>Member Registration</h1>
    <form method="post" action="{{ route('front.entry.post') }}">
        @csrf
        <div><label>Name <input name="name" value="{{ old('name') }}" required></label></div>
        <div><label>Email <input name="email" type="email" value="{{ old('email') }}" required></label></div>
        <div><label>Login ID <input name="login_id" value="{{ old('login_id') }}" required></label></div>
        <div><label>Password <input name="password" type="password" required></label></div>
        <div><label>Confirm Password <input name="password_confirmation" type="password" required></label></div>
        <button type="submit">Register</button>
    </form>
    <p><a href="{{ route('login') }}">Back to login</a></p>
</x-layout>
