<!doctype html>
<html>
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>{{ $title ?? 'App' }}</title>
</head>
<body>
@if(session('status'))
    <p style="color:green">{{ session('status') }}</p>
@endif
@if($errors->any())
    <ul style="color:red">
    @foreach($errors->all() as $e)
        <li>{{ $e }}</li>
    @endforeach
    </ul>
@endif
{{ $slot }}
</body>
</html>
