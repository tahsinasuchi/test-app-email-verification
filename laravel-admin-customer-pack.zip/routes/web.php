<?php

use App\Http\Controllers\AdminAuthController;
use App\Http\Controllers\AdminMemberController;
use App\Http\Controllers\CustomerAdminController;
use App\Http\Controllers\FrontAuthController;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// -------- FRONT (Members) --------
Route::get('/login', [FrontAuthController::class, 'showLogin'])->name('login');
Route::post('/login', [FrontAuthController::class, 'login'])->name('front.login.post');
Route::post('/logout', [FrontAuthController::class, 'logout'])->name('front.logout');

Route::get('/entry', [FrontAuthController::class, 'showEntry'])->name('front.entry');
Route::post('/entry', [FrontAuthController::class, 'entry'])->name('front.entry.post');

// email verification (member)
Route::get('/email/verify', function () {
    return view('front.auth.verify-notice');
})->middleware('auth')->name('verification.notice');

Route::get('/email/verify/{id}/{hash}', function (EmailVerificationRequest $request) {
    $request->fulfill();
    return redirect()->route('login')->with('status','Email Verified. You can login now.');
})->middleware(['auth', 'signed'])->name('verification.verify');

Route::post('/email/verification-notification', function (Request $request) {
    $request->user()->sendEmailVerificationNotification();
    return back()->with('status', 'Verification link sent!');
})->middleware(['auth', 'throttle:6,1'])->name('verification.send');

// mypage (ensure verified via middleware in controllers if desired)
Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/mypage/edit', [FrontAuthController::class, 'mypageEdit'])->name('front.mypage.edit');
    Route::post('/mypage/edit', [FrontAuthController::class, 'mypageUpdate'])->name('front.mypage.update');
});

// -------- ADMIN --------
Route::prefix('admin')->group(function () {
    Route::get('/register', [AdminAuthController::class, 'showRegister'])->name('admin.register');
    Route::post('/register', [AdminAuthController::class, 'register'])->name('admin.register.post');

    Route::get('/login', [AdminAuthController::class, 'showLogin'])->name('admin.login');
    Route::post('/login', [AdminAuthController::class, 'login'])->name('admin.login.post');
    Route::post('/logout', [AdminAuthController::class, 'logout'])->name('admin.logout');

    // admin email verify screen (needs separate guard auth)
    Route::get('/email/verify', function () {
        return view('admin.auth.verify-notice');
    })->middleware('auth:admin')->name('admin.verification.notice');

    Route::get('/email/verify/{id}/{hash}', function (EmailVerificationRequest $request) {
        $user = auth('admin')->user();
        // temporarily set the default user resolver for verification
        auth()->setUser($user);
        $request->fulfill();
        return redirect()->route('admin.login')->with('status','Email Verified. You can login now.');
    })->middleware(['auth:admin','signed'])->name('admin.verification.verify');

    Route::post('/email/verification-notification', function (Request $request) {
        $user = auth('admin')->user();
        $user->sendEmailVerificationNotification();
        return back()->with('status', 'Verification link sent!');
    })->middleware(['auth:admin','throttle:6,1'])->name('admin.verification.send');

    // Protected admin area
    Route::middleware('auth:admin')->group(function () {
        // Admin members CRUD
        Route::get('/member', [AdminMemberController::class, 'index'])->name('admin.members.index');
        Route::get('/member/new', [AdminMemberController::class, 'create'])->name('admin.members.create');
        Route::post('/member/new', [AdminMemberController::class, 'store'])->name('admin.members.store');
        Route::get('/member/{id}/edit', [AdminMemberController::class, 'edit'])->name('admin.members.edit');
        Route::post('/member/{id}/edit', [AdminMemberController::class, 'update'])->name('admin.members.update');
        Route::get('/member/export/csv', [AdminMemberController::class, 'exportCsv'])->name('admin.members.csv');

        // Customers CRUD for admins
        Route::get('/customer', [CustomerAdminController::class, 'index'])->name('admin.customers.index');
        Route::get('/customer/new', [CustomerAdminController::class, 'create'])->name('admin.customers.create');
        Route::post('/customer/new', [CustomerAdminController::class, 'store'])->name('admin.customers.store');
        Route::get('/customer/{id}/edit', [CustomerAdminController::class, 'edit'])->name('admin.customers.edit');
        Route::post('/customer/{id}/edit', [CustomerAdminController::class, 'update'])->name('admin.customers.update');
        Route::get('/customer/export/csv', [CustomerAdminController::class, 'exportCsv'])->name('admin.customers.csv');
    });
});
